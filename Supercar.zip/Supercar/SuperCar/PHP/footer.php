<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Footer</title>
    <link rel="stylesheet" href="../Css/Footer.css">
   </head>
<body bgcolor="black">
<div class="footer-basic">
            <footer>
                <div class="line">
                <ul class="social_icon">
                    <li><a href="https://www.facebook.com/"><ion-icon name="logo-facebook"></ion-icon></a></li>
                    <li><a href="https://www.twitter.com"><ion-icon name="logo-twitter"></ion-icon></a></li>
                    <li><a href="#"><ion-icon name="logo-linkedin"></ion-icon></a></li>
                    <li><a href="https://www.instagram.com/"><ion-icon name="logo-instagram"></ion-icon></a></li>
                </ul>
                <UL class="menus">
                    <li><a href="Privacy.php">Politique de Confidentialité</a></li> 
                    <li>|</li> 
                    <li><a href="mentionlegale.php">Mention légale</a></li>
                </UL>
                <p> ©2023 SuperCar | Le meilleur pour vous</p>
            </footer>
            <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
            <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        </div>
</body>
</html>
